module.exports = {
  content: [
    "./src/**/*.{html,js,jsx,ts,tsx}", // Add your paths
  ],
  theme: {
    extend: {},
  },
  plugins: [],
};
