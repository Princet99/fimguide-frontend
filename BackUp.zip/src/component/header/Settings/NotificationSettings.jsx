import { useState, useEffect, useCallback } from "react";

const NotificationSettings = () => {
  const userId = sessionStorage.getItem("userId");
  const sessionStoredUser = JSON.parse(sessionStorage.getItem("user") || "{}");
  const sessionStoredEmail = sessionStoredUser?.email || "";

  // State
  const [email, setEmail] = useState(sessionStoredEmail);
  const [emailMessage, setEmailMessage] = useState(""); // Specific for email update
  const [isEmailError, setIsEmailError] = useState(false); // Specific for email update

  const [emailNotifications, setEmailNotifications] = useState(true);
  const [reminderDays, setReminderDays] = useState(7);
  const [loading, setLoading] = useState(false);
  const [settingsStatusMessage, setSettingsStatusMessage] = useState(""); // Specific for main settings save
  const [isSettingsError, setIsSettingsError] = useState(false); // Specific for main settings save

  // Assuming these are static for the "Payment Reminder" rule
  const notificationType = "Payment Reminder";
  const deliveryMethod = "Email";
  const sc_ln_no = "fa0011"; // Loan number or some identifier for the rule
  const sc_payor = "1"; // Payor ID or some identifier for the rule

  const apiUrl =
    process.env.NODE_ENV === "production"
      ? "https://fimguide-backend.onrender.com"
      : "http://localhost:3030";

  // Function to update user's primary email in the backend (no token used here)
  const updateUserPrimaryEmailInBackend = useCallback(
    async (emailToUpdate) => {
      if (!userId || !emailToUpdate) return;
      try {
        console.log(
          `Syncing primary email for userId: ${userId} with email: ${emailToUpdate}`
        );
        const response = await fetch(`${apiUrl}/users/${userId}/email`, {
          method: "PUT",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ newEmail: emailToUpdate }),
        });

        if (!response.ok) {
          console.error(
            `Failed to update user email in backend: ${response.status}`
          );
        }
      } catch (error) {
        console.error("Error syncing user email in backend:", error);
      }
    },
    [userId, apiUrl]
  );

  // Effect to fetch user email and notification settings on component mount
  useEffect(() => {
    if (!userId) {
      setSettingsStatusMessage("User ID not found. Please log in.");
      setIsSettingsError(true);
      return;
    }

    // 1. Fetch user's primary email (if not already in session)
    const fetchAndSyncPrimaryEmail = async () => {
      if (!sessionStoredEmail) {
        try {
          const response = await fetch(`${apiUrl}/users/${userId}/email`);
          if (response.ok) {
            const data = await response.json();
            if (data?.email) {
              setEmail(data.email);
              const user = JSON.parse(sessionStorage.getItem("user") || "{}");
              user.email = data.email;
              sessionStorage.setItem("user", JSON.stringify(user));
            }
          } else {
            console.warn(`Failed to fetch user email: ${response.status}`);
          }
        } catch (error) {
          console.error("Error fetching user email:", error);
        }
      } else {
        updateUserPrimaryEmailInBackend(sessionStoredEmail);
      }
    };

    // 2. Fetch user's notification preferences (no token used here)
    const fetchNotificationSettings = async () => {
      setLoading(true);
      try {
        const response = await fetch(
          `${apiUrl}/api/reminders/notification-settings/${userId}?notificationType=${encodeURIComponent(
            notificationType
          )}`
          // No Authorization header needed if backend allows unauthenticated access for this endpoint
        );
        if (response.ok) {
          const data = await response.json();
          if (data) {
            setEmailNotifications(data.receiveNotifications);
            setReminderDays(data.intervalDays);
            // If the rule's email can differ from primary user email, uncomment below:
            // setEmail(data.userEmail);
          } else {
            console.log(
              "No existing notification settings found. Using defaults."
            );
            setEmailNotifications(true);
            setReminderDays(7);
          }
        } else if (response.status === 404) {
          console.log("No settings found for this user/type. Using defaults.");
          setEmailNotifications(true);
          setReminderDays(7);
        } else {
          console.error(
            `Failed to fetch notification settings: ${response.status}`
          );
          setSettingsStatusMessage("Failed to load notification settings.");
          setIsSettingsError(true);
        }
      } catch (error) {
        console.error("Error fetching notification settings:", error);
        setSettingsStatusMessage(
          "Network error during settings load. Please try again."
        );
        setIsSettingsError(true);
      } finally {
        setLoading(false);
      }
    };

    fetchAndSyncPrimaryEmail();
    fetchNotificationSettings();
  }, [
    userId,
    apiUrl,
    sessionStoredEmail,
    updateUserPrimaryEmailInBackend,
    notificationType,
  ]);

  const handleEmailChange = (e) => {
    setEmail(e.target.value);
    setEmailMessage("");
    setIsEmailError(false);
  };

  const handleSavePrimaryEmail = async () => {
    if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      setEmailMessage("Please enter a valid email address.");
      setIsEmailError(true);
      return;
    }

    setLoading(true);
    setEmailMessage("");
    setIsEmailError(false);

    try {
      const response = await fetch(`${apiUrl}/users/${userId}/email`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        // No Authorization header here either if the /users/:userId/email endpoint is also public
        body: JSON.stringify({ newEmail: email }),
      });

      const data = await response.json();

      if (response.ok) {
        setEmailMessage(data.message || "Email updated successfully!");
        setIsEmailError(false);
        const user = JSON.parse(sessionStorage.getItem("user") || "{}");
        user.email = email;
        sessionStorage.setItem("user", JSON.stringify(user));
      } else {
        setEmailMessage(
          data.message || "Failed to update email. Please try again."
        );
        setIsEmailError(true);
      }
    } catch (error) {
      console.error("Error updating email:", error);
      setEmailMessage("Network error. Could not connect to the server.");
      setIsEmailError(true);
    } finally {
      setLoading(false);
    }
  };

  const handleReminderDaysChange = (e) => {
    const value = parseInt(e.target.value, 10);
    if (!isNaN(value) && value >= 0 && value <= 14) {
      setReminderDays(value);
    } else if (e.target.value === "") {
      setReminderDays("");
    }
  };

  const handleSaveSettings = async () => {
    setLoading(true);
    setSettingsStatusMessage("");
    setIsSettingsError(false);

    if (!userId) {
      setSettingsStatusMessage("User ID not found. Cannot save settings.");
      setIsSettingsError(true);
      setLoading(false);
      return;
    }

    // Explicitly add userId to the payload as requested
    const payload = {
      userId: 4, // Ensure userId is a number
      userEmail: email,
      receiveNotifications: emailNotifications,
      intervalDays: reminderDays,
      sc_ln_no: sc_ln_no,
      sc_payor: sc_payor,
      notificationType: notificationType,
      deliveryMethod: deliveryMethod,
    };
    console.log(payload);

    try {
      const response = await fetch(
        `${apiUrl}/api/reminders/notification-settings`,
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            // Removed 'Authorization' header as per your request
          },
          body: JSON.stringify(payload),
        }
      );

      const data = await response.json();

      if (response.ok) {
        setSettingsStatusMessage(
          data.message || "Settings saved successfully!"
        );
        setIsSettingsError(false);
      } else {
        setSettingsStatusMessage(
          data.message || "Failed to save settings. Please try again."
        );
        setIsSettingsError(true);
      }
    } catch (error) {
      console.error("Error saving notification settings:", error);
      setSettingsStatusMessage(
        "Network error. Could not connect to the server."
      );
      setIsSettingsError(true);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="p-6 bg-white rounded-lg shadow-xl max-w-m mx-auto my-8 font-inter">
      {/* Email Update */}
      <h3 className="text-2xl font-bold text-gray-800 my-6">Notifications</h3>
      <div className="bg-white rounded-lg shadow-md mb-6">
        <label htmlFor="email" className="block text-lg font-semibold mb-2">
          Your Preferred Contact Email:
        </label>
        <input
          type="email"
          id="email"
          value={email}
          onChange={handleEmailChange}
          placeholder="Enter your email to update"
          className="w-full px-4 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
        />
      </div>
      {emailMessage && (
        <p
          className={`mt-2 text-sm ${
            isEmailError ? "text-red-500" : "text-green-500"
          }`}
        >
          {emailMessage}
        </p>
      )}
      <button
        onClick={handleSavePrimaryEmail}
        className="w-full bg-blue-600 hover:bg-blue-700 text-white font-semibold py-3 px-6 rounded-lg shadow-md transition duration-300 ease-in-out transform hover:scale-105"
        disabled={loading}
      >
        {loading ? (
          <div className="flex items-center justify-center">
            <svg
              className="animate-spin h-5 w-5 text-white mr-3"
              viewBox="0 0 24 24"
            >
              <circle
                className="opacity-25"
                cx="12"
                cy="12"
                r="10"
                stroke="currentColor"
                strokeWidth="4"
              ></circle>
              <path
                className="opacity-75"
                fill="currentColor"
                d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
              ></path>
            </svg>
            Updating Email...
          </div>
        ) : (
          "Update Email"
        )}
      </button>

      <h3 className="text-2xl font-bold text-gray-800 my-6">
        Optional Notifications
      </h3>

      <div className="mb-5">
        <label className="flex items-center cursor-pointer text-gray-700">
          <input
            type="checkbox"
            checked={emailNotifications}
            onChange={() => setEmailNotifications(!emailNotifications)}
            className="form-checkbox h-5 w-5 text-blue-600 rounded focus:ring-blue-500 mr-3"
          />
          <span className="text-lg">Receive Payment Reminders</span>
        </label>
      </div>

      {emailNotifications && (
        <div className="mb-6 ml-8">
          <label
            htmlFor="reminderDays"
            className="text-lg text-gray-700 flex items-center"
          >
            Remind me
            <input
              type="number"
              id="reminderDays"
              value={reminderDays}
              onChange={handleReminderDaysChange}
              min="0"
              max="14"
              className="w-20 ml-3 px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500 text-center text-lg"
            />
            <span className="ml-2">days before</span>
          </label>
        </div>
      )}

      <button
        onClick={handleSaveSettings}
        className="w-full bg-blue-600 hover:bg-blue-700 text-white font-semibold py-3 px-6 rounded-lg shadow-md transition duration-300 ease-in-out transform hover:scale-105"
        disabled={loading}
      >
        {loading ? (
          <div className="flex items-center justify-center">
            <svg
              className="animate-spin h-5 w-5 text-white mr-3"
              viewBox="0 0 24 24"
            >
              <circle
                className="opacity-25"
                cx="12"
                cy="12"
                r="10"
                stroke="currentColor"
                strokeWidth="4"
              ></circle>
              <path
                className="opacity-75"
                fill="currentColor"
                d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
              ></path>
            </svg>
            Saving...
          </div>
        ) : (
          "Save Notification Settings"
        )}
      </button>

      {settingsStatusMessage && (
        <div
          className={`mt-6 p-4 rounded-md text-center text-lg ${
            isSettingsError
              ? "bg-red-100 text-red-700"
              : "bg-green-100 text-green-700"
          }`}
        >
          {settingsStatusMessage}
        </div>
      )}

      <div className="mt-10">
        <h4 className="text-xl font-semibold text-gray-800 mb-4">
          Required Notifications
        </h4>
        <div className="p-6 bg-gray-50 rounded-lg shadow-sm space-y-6">
          {/* Past Due Notice */}
          <div className="flex items-center">
            <label className="flex items-center">
              <input
                type="checkbox"
                checked
                disabled
                className="form-checkbox h-5 w-5 text-gray-400 cursor-not-allowed mr-3"
              />
              <span className="text-lg text-gray-800">
                Past Due Notice{" "}
                <span className="group relative cursor-help">
                  <span className="tooltip-trigger">?</span>
                  <div className="absolute top-full left-0 mt-2 w-64 p-2 text-sm bg-gray-800 text-white rounded shadow-lg hidden group-hover:block z-50">
                    FiMguide will send you a notice when an SP becomes more than
                    10 days past due.
                  </div>
                </span>
              </span>
            </label>
          </div>
          {/* Notice Before Credit Reporting */}
          <div className="flex items-center">
            <label className="flex items-center">
              <input
                type="checkbox"
                checked
                disabled
                className="form-checkbox h-5 w-5 text-gray-400 cursor-not-allowed mr-3"
              />
              <span className="text-lg text-gray-800">
                Notice Before Credit Reporting{" "}
                <span className="group relative cursor-help">
                  <span className="tooltip-trigger">?</span>
                  <div className="absolute top-full left-0 mt-2 w-64 p-2 text-sm bg-gray-800 text-white rounded shadow-lg hidden group-hover:block z-50">
                    FiMguide will send you a warning that we will report
                    negative credit information if you don’t pay the Past Due SP
                    within the next 30 days.
                  </div>
                </span>
              </span>
            </label>
          </div>
          {/* Notice After a Negative Credit Report */}
          <div className="flex items-center">
            <label className="flex items-center">
              <input
                type="checkbox"
                checked
                disabled
                className="form-checkbox h-5 w-5 text-gray-400 cursor-not-allowed mr-3"
              />
              <span className="text-lg text-gray-800">
                Notice After a Negative Credit Report{" "}
                <span className="group relative cursor-help">
                  <span className="tooltip-trigger">?</span>
                  <div className="absolute top-full left-0 mt-2 w-64 p-2 text-sm bg-gray-800 text-white rounded shadow-lg hidden group-hover:block z-50">
                    FiMguide will send you notification after we report negative
                    credit information.
                  </div>
                </span>
              </span>
            </label>
          </div>
        </div>
      </div>
      <footer className="bg-gray-100 p-4 text-sm italic border-t text-red-700 mt-6">
        Please keep in mind: you are responsible for resolving Past Due amounts
        even if these notices are not received.
      </footer>
    </div>
  );
};

export default NotificationSettings;