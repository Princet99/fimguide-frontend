import React from "react";
import "./style/style.css";
import FloatingButtonWithTable from "./action_button/FloatingButtonWithTable";


const Home = () => {

  return (
    <>
      Home
      {/* <FloatingButtonWithTable /> */}
    </>
  );
};

export default Home;
